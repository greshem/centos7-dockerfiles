/*
 Navicat Premium Data Transfer

 Source Server         : 10.99.2.56
 Source Server Type    : MySQL
 Source Server Version : 50556
 Source Host           : 10.99.2.56:3306
 Source Schema         : mwcloud_oper_init

 Target Server Type    : MySQL
 Target Server Version : 50556
 File Encoding         : 65001

 Date: 06/12/2017 16:27:26
*/
CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mwcloud_oper_240`;

USE `mwcloud_oper_240`;


SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for T_CC_APPLICAION_CLASSIFY
-- ----------------------------
-- 应用分类表(编号/分类名称/添加时间/是否可用/父级ID)
DROP TABLE IF EXISTS `T_CC_APPLICAION_CLASSIFY`;
CREATE TABLE `T_CC_APPLICAION_CLASSIFY`  (
  `ID` int(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `NUM` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '编号',
  `PARENT_ID` int(20) NULL DEFAULT NULL COMMENT '父级ID',
  `CLASSIFY_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分类名称',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '添加时间',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '应用分类表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_APPLICAION_OPEN_RECORD
-- ----------------------------
-- 应用开通记录表(应用ID/开通时间/开通人)
DROP TABLE IF EXISTS `T_CC_APPLICAION_OPEN_RECORD`;
CREATE TABLE `T_CC_APPLICAION_OPEN_RECORD`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICAION_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用ID',
  `OPEN_TIME` datetime NULL DEFAULT NULL COMMENT '开通时间',
  `OPEN_USER` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用ID',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '应用开通记录表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_APPLICAION_SPEC
-- ----------------------------
-- 应用规格表(规格名称/单位/编号/是否可用/售价/应用ID)
DROP TABLE IF EXISTS `T_CC_APPLICAION_SPEC`;
CREATE TABLE `T_CC_APPLICAION_SPEC`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICAION_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用ID',
  `SPEC_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '规格名称',
  `UNIT` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '单位',
  `NUM` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '编号',
  `PRICE` decimal(10, 2) NULL DEFAULT NULL COMMENT '售价',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '应用规格表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_DICT_CODE
-- ----------------------------
-- 字典表(应用单位)
DROP TABLE IF EXISTS `T_CC_DICT_CODE`;
CREATE TABLE `T_CC_DICT_CODE`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `KEY` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'key',
  `VAL` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'val',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_ENTERPRISE
-- ----------------------------
-- 企业表(企业ID/企业名称/logo/介绍/创建时间/所在地/创建时间/提交时间/状态/
-- 详细地址/联系人/联系电话/联系人邮箱/税号/法人姓名/营业执照图片/身份证号/法人身份证正面/法人身份证反面)
DROP TABLE IF EXISTS `T_CC_ENTERPRISE`;
CREATE TABLE `T_CC_ENTERPRISE`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ENTERPRISE_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '企业名称',
  `LOGO` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'logo',
  `INTRODUCE` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '介绍',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `AREA` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '所在地',
  `SUBMIT_TIME` datetime NULL DEFAULT NULL COMMENT '提交时间',
  `STATUS` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态编码，已创建：00，待认证：01，被驳回：02，已认证：03',
  `ADDRESS` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '详细地址',
  `LINKMAN` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人',
  `LINKMAN_PHONE` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `LINKMAN_EMAIL` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系人邮箱',
  `TAX_NUM` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '税号',
  `LEGAL_PERSON` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '法人姓名',
  `BUSINESS_LICENSE` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '营业执照图片',
  `IDENTITY_NUM` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '法人身份证号',
  `EGAL_PERSON_IDENTITY_POS` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '法人身份证正面',
  `EGAL_PERSON_IDENTITY_NEG` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '法人身份证反面',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  `OWNER_ID` int(20) NULL DEFAULT NULL COMMENT '管理员ID',
  `CREATER` int(20) NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '企业表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_ENTERPRISE_AUTHENTICATION
-- ----------------------------
-- 企业认证记录表(企业ID/驳回理由/驳回时间)
DROP TABLE IF EXISTS `T_CC_ENTERPRISE_AUTHENTICATION`;
CREATE TABLE `T_CC_ENTERPRISE_AUTHENTICATION`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ENTERPRISE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '企业ID',
  `REJECT_REASON` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '驳回理由',
  `REJECT_TIME` datetime NULL DEFAULT NULL COMMENT '驳回时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '企业认证记录表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_ENTERPRISE_USER
-- ----------------------------
-- 企业用户表(用户开通应用(字符串拼接)ID/企业ID/用户ID/账户类型/用户状态/)
DROP TABLE IF EXISTS `T_CC_ENTERPRISE_USER`;
CREATE TABLE `T_CC_ENTERPRISE_USER`  (
  `ID` int(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICAION_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户开通应用(字符串拼接)ID',
  `ENTERPRISE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '企业ID',
  `USER_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户ID',
  `ACCOUNT_TYPE` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '账户类型，普通账号：00，管理员：01，子账号：02',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '企业用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_PURCHASER_APPLICAION
-- ----------------------------
-- 采购商开通应用表
DROP TABLE IF EXISTS `T_CC_PURCHASER_APPLICAION`;
CREATE TABLE `T_CC_PURCHASER_APPLICAION`  (
  `ID` int(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICAION_ID` int(20) NULL DEFAULT NULL COMMENT '应用ID',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  `ENTERPRISE_ID` int(20) NULL DEFAULT NULL COMMENT '企业ID',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `STATUS` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态编码',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '采购商开通应用表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_SUPPLIER_APPLICAION
-- ----------------------------
-- 供应商应用表(应用分类ID/平台访问地址/原始访问地址/应用编号/应用亮点/应用说明/排序/权重/图片/名称/介绍/精品推荐/企业ID/
-- 创建时间/发布时间/点击数/开通数/应用详情/销量/应用状态)
DROP TABLE IF EXISTS `T_CC_SUPPLIER_APPLICAION`;
CREATE TABLE `T_CC_SUPPLIER_APPLICAION`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICATION_CLASSIFY_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '应用分类ID',
  `PLATFORM_ACCESS_ADDRESS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '平台访问地址',
  `ORIGINAL_ACCESS_ADDRESS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '原始访问地址',
  `APPLICATION_NUMBER` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用编号',
  `APPLICATION_HIGHLIGHTS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用亮点',
  `APPLICATION_NOTES` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用说明',
  `SORT` int(11) NULL DEFAULT NULL COMMENT '排序',
  `WEIGHT` decimal(10, 2) NULL DEFAULT NULL COMMENT '权重',
  `PIC` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片',
  `NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `INTRODUCE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '介绍',
  `HIGH_QUALITY_RECOMMENDATION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '精品推荐',
  `ENTERPRISE` int(20) NULL DEFAULT NULL COMMENT '企业ID',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `DEPLOY_TIME` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `NUM_OF_CLICK` int(11) NULL DEFAULT NULL COMMENT '点击数',
  `NUM_OF_OPEN` int(255) NULL DEFAULT NULL COMMENT '开通数',
  `APPLICATION_DETAIL` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用详情',
  `SALES_NUM` int(11) NULL DEFAULT NULL COMMENT '销量',
  `APPLICATION_STATUS` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用状态',
  `PUBLISHER_ID` int(20) NULL DEFAULT NULL COMMENT '创建人',
  `AUTHORIZED_GRANT_TYPES` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'authorization_code,password,refresh_token' COMMENT '授权类型，框架字段',
  `SCOPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'read,write' COMMENT '权限范围，框架字段',
  `CLIENT_SECRET` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'zhaozhizao_secret' COMMENT '访问密钥，框架字段',
  `CLIENT_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'zhaozhizao_client' COMMENT '客户端标识，框架字段',
  `RESOURCE_IDS` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'unity-resource' COMMENT '资源ID集合，框架字段',
  `AUTHORITIES` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'ROLE_USER,ROLE_UNITY' COMMENT 'SECURITY权限值，框架字段',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '可用标识',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '供应商应用表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_SUPPLIER_APPLICAION_CHANGE_RECORD
-- ----------------------------
-- 供应商应用变更记录表(上架时间/下架时间/应用ID)
DROP TABLE IF EXISTS `T_CC_SUPPLIER_APPLICAION_CHANGE_RECORD`;
CREATE TABLE `T_CC_SUPPLIER_APPLICAION_CHANGE_RECORD`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICAION_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用ID',
  `ENABLE_TIME` datetime NULL DEFAULT NULL COMMENT '上架时间',
  `DISABLE_TIME` datetime NULL DEFAULT NULL COMMENT '下架时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '供应商应用变更记录表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_SUPPLIER_SOLD
-- ----------------------------
-- 供应商应用已售表(应用ID/采购商ID/采购时间/已售软件是否开通状态/应用规格ID/销售总价/销售数量)
DROP TABLE IF EXISTS `T_CC_SUPPLIER_SOLD`;
CREATE TABLE `T_CC_SUPPLIER_SOLD`  (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `APPLICATION_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '应用ID',
  `PURCHASER_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '采购商ID',
  `PURCHASER_TIME` datetime NULL DEFAULT NULL COMMENT '采购时间',
  `SOFT_OPEN_STATE` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '已售软件是否开通状态',
  `APPLICATION_SPEC_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用规格ID',
  `TOTAL_SALE_PRICE` decimal(10, 2) NULL DEFAULT NULL COMMENT '销售总价',
  `SALE_NUM` int(11) NULL DEFAULT NULL COMMENT '销售数量',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '供应商应用已售表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_USER
-- ----------------------------
-- 用户表(姓名/账户名/邮箱/手机/密码)
DROP TABLE IF EXISTS `T_CC_USER`;
CREATE TABLE `T_CC_USER`  (
  `ID` int(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `USERNAME` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '账户名',
  `PASSWORD` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `EMAIL` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `PHONE` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '手机',
  `CREATER` int(20) NULL DEFAULT NULL COMMENT '创建者',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `ENABLED` bit(1) NULL DEFAULT b'1' COMMENT '是否启用',
  `DELETED` bit(1) NULL DEFAULT b'0' COMMENT '是否删除',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_USER_PRIVILEGE
-- ----------------------------
-- 用户权限表
DROP TABLE IF EXISTS `T_CC_USER_PRIVILEGE`;
CREATE TABLE `T_CC_USER_PRIVILEGE`  (
  `USER_ID` int(20) NULL DEFAULT NULL,
  `PRIVILEGE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  INDEX `user_id_index`(`USER_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户权限表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for T_CC_USER_SERVICE_AUTHORIZE
-- ----------------------------
-- 用户软件授权记录表
DROP TABLE IF EXISTS `T_CC_USER_SERVICE_AUTHORIZE`;
CREATE TABLE `T_CC_USER_SERVICE_AUTHORIZE`  (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `TENANT_ID` bigint(20) NOT NULL COMMENT '企业id',
  `USER_ID` bigint(20) NOT NULL COMMENT '用户id',
  `SERVICE_ID` varchar(22) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '软件id',
  `CREATE_TIME` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户软件授权记录表' ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
